﻿ONE BITE HIGHER (Windows)

1. Extract this folder somewhere (e.g. Documents).
2. Double-click 'Install.cmd' to add a game icon to your Desktop and Start menu.
3. Double-click the icon to play (opens as an Edge app window).

If 'Windows protected your PC' appears, click 'More info' → 'Run anyway'.
If you move the folder, run 'Install.cmd' again.
