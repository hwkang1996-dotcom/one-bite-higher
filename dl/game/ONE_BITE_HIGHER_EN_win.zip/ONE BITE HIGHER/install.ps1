﻿$ErrorActionPreference = 'Stop'
$d = Split-Path -Parent $MyInvocation.MyCommand.Path
$html = Join-Path $d 'game.html'
$ico = Join-Path $d 'icon.ico'
$url = 'file:///' + ($html -replace '\\','/' -replace ' ','%20')
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$ws = New-Object -ComObject WScript.Shell
$dirs = @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))
foreach ($dir in $dirs) {
  $s = $ws.CreateShortcut((Join-Path $dir 'ONE BITE HIGHER.lnk'))
  if ($edge) { $s.TargetPath = $edge; $s.Arguments = "--app=`"$url`" --window-size=1280,800" } else { $s.TargetPath = $html }
  $s.IconLocation = "$ico,0"; $s.WorkingDirectory = $d; $s.Description = 'ONE BITE HIGHER'
  $s.Save()
}
Write-Host 'ONE BITE HIGHER: desktop icon created.'
if ($edge) { Start-Process $edge -ArgumentList "--app=`"$url`"", '--window-size=1280,800' } else { Start-Process $html }
