ONE BITE HIGHER (Mac)

1. Move the 'ONE BITE HIGHER' app to Applications or your Desktop.
2. Double-click the icon to play.
   (Opens as an app window in Chrome, Edge or Brave; otherwise in Safari)

If macOS says "'ONE BITE HIGHER' Not Opened":
 1) Click 'Done' (not 'Move to Trash').
 2) System Settings → Privacy & Security → scroll to Security →
    click 'Open Anyway' next to ONE BITE HIGHER → enter your password.
 3) Double-click the app again → 'Open'. Only needed once.
Works offline.
